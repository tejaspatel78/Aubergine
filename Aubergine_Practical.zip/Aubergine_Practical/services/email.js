const logger = require('pino')({ level: 'debug' });
const nodemailer = require('nodemailer');

/*************************************************************************************
@Purpose    :   To send an email
@Parameter  :   {
    email       :   'raj@gmail.com',
    fileName    :   'fileName'
}
**************************************************************************************/
const sendMail = async (email, fileName) => {
    try {
        const smtpTransport = nodemailer.createTransport({
            service: 'Gmail',
            auth: {
                user: 'EMAIL_USERNAME',
                pass: 'EMAIL_PASSWORD'
            }
        });
        const mailOptions = {
            to: email,
            from: '"Covid Statistics " FROM_EMAIL_ADDRESS',
            subject: fileName,
            attachments: [{
                fileName,
                path: __dirname + `/../public/${fileName}.png`
            }]
        };
        await smtpTransport.sendMail(mailOptions);
    } catch (error) {
        logger.warn(`Error while sendMail(). Error = %j %s`, error, error);
        throw error;
    }
}

module.exports = {
    sendMail
}