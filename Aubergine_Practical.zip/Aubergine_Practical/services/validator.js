const logger = require('pino')({ level: 'debug' });
const Joi = require('joi');

/*************************************************************************************
@Purpose    :   Function for user registration validator
@Parameter  :   {
    countryCode     :   'IN',
    firstName       :   'Roy',
    lastName        :   'Raj',
    countryName     :   'India'
    password        :   'raj@1234',
    email           :   'raj.roy@gmail.com'
}
@Return     :   JSON String
**************************************************************************************/
const signUpValidator = () => {
    return async (req, res, next) => {
        try {
            req.schema = Joi.object().keys({
                lastName: Joi.string().trim().required().error(() => 'Please provide lastName'),
                firstName: Joi.string().trim().required().error(() => 'Please provide firstName'),
                countryName: Joi.string().trim().required().error(() => 'Please provide countryName'),
                countryCode: Joi.string().trim().required().error(() => 'Please provide countryCode'),
                password: Joi.string().trim().required().error(() => 'Please provide proper password'),
                email: Joi.string().trim().email().required().error(() => 'Please provide valid email')
            });
            next();
        } catch (error) {
            logger.warn(`Error while signUpValidator(). Error: %j %s`, error, error);
            return res.send({ status: 0, message: 'Internal Server Error' });
        }
    };
}

/*************************************************************************************
@Purpose    :   Function for user login validator
@Parameter  :   {
    password        :   'raj@1234',
    email           :   'raj.roy@gmail.com'
}
@Return     :   JSON String
**************************************************************************************/
const loginValidator = () => {
    return async (req, res, next) => {
        try {
            req.schema = Joi.object().keys({
                password: Joi.string().trim().required().error(() => 'Please provide proper password'),
                email: Joi.string().trim().email().required().error(() => 'Please provide valid email')
            });
            next();
        } catch (error) {
            logger.warn(`Error while loginValidator(). Error: %j %s`, error, error);
            return res.send({ status: 0, message: 'Internal Server Error' });
        }
    };
}

/*************************************************************************************
@Purpose    :   Function for get covid statistics validator
@Parameter  :   {
    password        :   'raj@1234',
    email           :   'raj.roy@gmail.com'
}
@Return     :   JSON String
**************************************************************************************/
const getStatisticsValidator = () => {
    return async (req, res, next) => {
        try {
            req.schema = Joi.object().keys({
                countryCode: Joi.string().trim().error(() => 'Please provide proper countryCode'),
                duration: Joi.object().keys({
                    toDate: Joi.date().required().error(() => 'Required toDate'),
                    fromDate: Joi.date().required().error(() => 'Required fromDate')
                })
            });
            next();
        } catch (error) {
            logger.warn(`Error while getStatisticsValidator(). Error: %j %s`, error, error);
            return res.send({ status: 0, message: 'Internal Server Error' });
        }
    };
}

/*************************************************************************************
                    V A L I D A T E - B O D Y
**************************************************************************************/
const validateBody = (req, res, next) => {
    try {
        const { error } = Joi.validate(req.body, req.schema);
        if (error) return res.status(422).json({ status: 0, message: error.details[0].message });
        next();
    } catch (error) {
        logger.warn(`Error while validateBody(). Error: %j %s`, error, error);
        return res.send({ status: 0, message: 'Internal Server Error' });
    }
}

module.exports = {
    getStatisticsValidator,
    signUpValidator,
    loginValidator,
    validateBody
}