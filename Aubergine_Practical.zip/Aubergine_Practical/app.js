const { connect } = require('./lib/utils')
const bodyParser = require('body-parser')
const express = require('express');
var cors = require('cors');
const app = express();

app.use(bodyParser.json());
app.use(cors({ origin: '*' }));

//  Connect to database
connect();

require('./routes')(app)

module.exports = app;
