const plotly = require('plotly')('Tejas7878', 'b1v8uNwB3AEjqFjGvylU');
const logger = require('pino')({ level: 'debug' });
const { sendMail } = require('../services/email');
const { isEmpty } = require('lodash');
const moment = require('moment');
const axios = require('axios');
const fs = require('fs');

/*************************************************************************************
@Purpose    :   Get covid statistics
@Parameter  :   {
    headers :   { 
        Content-type    : 'application/json',
        Accept-Language : 'en'
    },
    body    :   {
        countryCode     :   'IN',
        duration        :   {
            from    :   '20-02-2021',
            to      :   '10-03-2021'
        }
    },
    params  :    {  }
}   
@Return     :   JSON String
*************************************************************************************/
const getStatistics = async (req, res) => {
    try {
        //  Get the current user data
        const { countryCode: userCountryCode, email } = req.currentUser;
        //  Get the request body data
        let { countryCode, duration } = req.body;
        //  Get default parameters
        countryCode = countryCode ? countryCode : userCountryCode;
        //  Give default duration if not exist
        if (!isEmpty(duration)) {
            if (moment(duration.fromDate).isAfter(duration.toDate)) {
                return res.send({ status: 0, message: 'fromDate can not be greater than toDate' });
            }
        } else duration = { fromDate: moment().subtract(15, 'days'), toDate: moment() }
        //  Get covid statistics
        let { data: { data: { timeline: covidStatistics } } } = await axios.get(`http://corona-api.com/countries/${countryCode}`);
        //  Filter data based on duration
        covidStatistics = covidStatistics.filter(obj => 
            moment(obj.updated_at).isSameOrAfter(moment(duration.fromDate)) && moment(obj.updated_at).isSameOrBefore(moment(duration.toDate).endOf('day'))
        );
        //  Different chart statistic names
        const chartNames = ['deaths', 'confirmed', 'recovered', 'new_confirmed', 'new_recovered', 'new_deaths', 'active'];
        //  Create payload for bar chart
        const chartData = []
        chartNames.forEach(chart => {
            const json = { x: [], y: [], name: chart, type: 'bar' };
            covidStatistics.forEach(obj => {
                json.x.push(obj.date);
                json.y.push(obj[chart]);
            });
            chartData.push(json);
        });
        const figure = { data: chartData };
        const imgOpts = { format: 'png', width: 1000, height: 500 };
        //  Create bar chart png using plotly
        plotly.getImage(figure, imgOpts, async (error, imageStream) => {
            if (error) return res.send({ status: 0, message: 'Error while generating chart' });
            const dir = __dirname + '/../public';
            if (!fs.existsSync(dir)) {
                fs.mkdirSync(dir);
            }
            const fileName = `Covid_Bar_Chart_From_${moment(duration.fromDate).format('DD-MM-YYYY')}_To_${moment(duration.toDate).format('DD-MM-YYYY')}`;
            const fileStream = await fs.createWriteStream(__dirname + `/../public/${fileName}.png`);
            imageStream.pipe(fileStream);
            await sendMail(email, fileName);
        });
        return res.send({ status: 1, message: 'Covid statistics fetched successfully', data: covidStatistics });
    } catch (error) {
        logger.warn(`Error while getStatistics(). Error: %j %s`, error, error);
        return res.send({ status: 0, message: 'Internal Server Error' });
    }
}

module.exports = {
    getStatistics
}