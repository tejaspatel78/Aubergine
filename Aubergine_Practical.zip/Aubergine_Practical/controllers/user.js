const { getUserToken } = require('./../lib/utils');
const logger = require('pino')({ level: 'debug' });
const { Users } = require('../models/user');
const { isEmpty } = require('lodash');
const bcrypt = require('bcryptjs');

/*************************************************************************************
@Purpose    :   User registration
@Parameter  :   {
    headers :   { 
        Content-type    : 'application/json',
        Accept-Language : 'en'
    },
    body    :   {
        countryCode     :   'IN',
        firstName       :   'Roy',
        lastName        :   'Raj',
        countryName     :   'India'
        password        :   'raj@1234',
        email           :   'raj.roy@gmail.com'
    },
    params  :    {  }
}   
@Return     :   JSON String
*************************************************************************************/
const userSignup = async (req, res) => {
    try {
        //  Get the request body data
        let { email, password } = req.body;
        email = email.toLowerCase().trim();
        //  Check user is exist or not
        const user = await Users.findOne({ email });
        if (!isEmpty(user)) return res.send({ status: 0, message: 'User already exists with given email' });
        //  Encrypt the password
        password = bcrypt.hashSync(password, 10);
        //  Generate user payload
        req.body.email = email;
        req.body.password = password;
        //  Save new user
        const newUser = await new Users(req.body).save();
        if (isEmpty(newUser)) return res.send({ status: 0, message: 'User not saved' });
        //  Generate the access token
        const generatedToken = await getUserToken(newUser._id);
        if (!generatedToken.status) return res.send({ status: 0, message: 'Error while generating access token' });
        const { data: accessToken } = generatedToken;
        return res.send({ status: 1, message: 'User registered successfully', data: { accessToken } });
    } catch (error) {
        logger.warn(`Error while userSignup(). Error: %j %s`, error, error);
        return res.send({ status: 0, message: 'Internal Server Error' });
    }
}

/*************************************************************************************
@Purpose    :   User Login
@Parameter  :   {
    headers :   { 
        Content-type    : 'application/json',
        Accept-Language : 'en'
    },
    body    :   {
        email           :   'raj.roy@gmail.com',
        password        :   'raj@1234'
    },
    params  :   {   }
}   
@Return     :   JSON String
*************************************************************************************/
const userLogin = async (req, res) => {
    try {
        //  Get the request body data
        let { email, password } = req.body;
        //  Make email as lowercase for unique
        email = email.toLowerCase().trim();
        //  Check user is existed or not
        const user = await Users.findOne({ email });
        if (isEmpty(user)) return res.send({ status: 0, message: 'User not exist with given email, Please register' });
        //  Validate the password
        if (!bcrypt.compareSync(password, user.password.toString())) return res.send({ status: 0, message: 'Please enter valid password' });
        //  Generate the access token
        const generatedToken = await getUserToken(user._id);
        if (!generatedToken.status) return res.send({ status: 0, message: 'Error while generating access token' });
        const { data: accessToken } = generatedToken;
        return res.send({ status: 1, message: 'User logged in successfully', data: { accessToken } });
    } catch (error) {
        logger.warn(`Error while userLogin(). Error: %j %s`, error, error);
        return res.send({ status: 0, message: 'Internal Server Error' });
    }
}

module.exports = {
    userSignup,
    userLogin
}