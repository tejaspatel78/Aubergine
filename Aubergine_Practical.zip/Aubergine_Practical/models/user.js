const { Schema, model } = require('mongoose');

const user = new Schema({
    password: Buffer,
    firstName: { type: String, trim: true },
    lastName: { type: String, trim: true },
    countryName: { type: String, trim: true },
    countryCode: { type: String, trim: true },
    email: { type: String, trim: true, required: true }
}, { timestamps: true });

const Users = model('users', user);

module.exports = { Users };