const { Schema, model } = require('mongoose');

const authTokensSchema = new Schema({
    token: Buffer,
    tokenExpiryTime: Date,
    userId: { type: Schema.Types.ObjectId, ref: 'users' }
}, { timestamps: true });

const AuthTokens = model('authtokens', authTokensSchema);

module.exports = { AuthTokens };