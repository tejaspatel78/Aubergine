const { getStatisticsValidator, validateBody } = require('../services/validator');
const { getStatistics } = require('../controllers/covid');
const { isUserAuthorized } = require('../lib/utils');
const express = require('express');
const router = express.Router();

router.post('/covid/getStatistics', isUserAuthorized(), getStatisticsValidator(), validateBody, getStatistics);

module.exports = router;
