const { signUpValidator, loginValidator, validateBody } = require('../services/validator');
const { userSignup, userLogin } = require('../controllers/user');
const express = require('express');
const router = express.Router();

router.post('/user/signUp', signUpValidator(), validateBody, userSignup);
router.post('/user/login', loginValidator(), validateBody, userLogin);

module.exports = router;
