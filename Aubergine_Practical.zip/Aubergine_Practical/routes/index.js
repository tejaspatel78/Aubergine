const usersRoute = require('./user');
const covidRoute = require('./covid');

module.exports = (app) => {
  app.use('/api', usersRoute)
  app.use('/api', covidRoute)
}
